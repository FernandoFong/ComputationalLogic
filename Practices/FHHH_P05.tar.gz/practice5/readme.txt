Equipo FHHH
Fong Baeza Luis Fernando Yang
Hernández Cháves Jorge Argenis
Herrera Mercado Juan Carlos
Hurtado Gutiérrez Marco Antonio 
