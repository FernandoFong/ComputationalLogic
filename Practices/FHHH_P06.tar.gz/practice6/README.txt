Fong Baeza Luis Fernando Yang
Hernádez Chávez Jorge Argenis
Herrera Mercado Juan Carlos
Hurtado Gómez Marco Antonio

Escribir las siguientes listas como términos con “.” (punto) 
como functor y [] representando a la lista vacía:

usando el punto como functor, ./2 y  
[] representando a la lista vacía:

a) [a,b]
.(a, .(b, []))

b) [a,[b,c],d]
.(a, .(.(b, .(c, [])), .(d, [])))

c) [a|[b,c]]
.(a, .(.(b, .(c, []))))

d) [[]|[]] 
.([], .([], []))
